﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerDefence.GameObjects
{
    class Enemy : GameObject
    {
        float speed;

        Rectangle hitBox;

        public int HealthPoints { get; set; }

        public bool ReachEnd { get; private set; }

        public Enemy(Texture2D tex, Vector2 pos, Rectangle rect) : base(tex, pos, rect)
        {
            speed = PathGenerator.path.beginT;

            this.pos = PathGenerator.path.GetPos(speed);

            HealthPoints = 10;
        }

        public override void Update()
        {
            pos = PathGenerator.path.GetPos(speed);

            hitBox = new Rectangle((int)pos.X - (rect.Width), (int)pos.Y - (rect.Height), rect.Width * 2, rect.Height * 2);

            if (speed < PathGenerator.path.endT)
            {
                speed += 2;
                ReachEnd = false;
            }
            else
            {
                ReachEnd = true;
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, pos, rect ,Color.White, 0, new Vector2(rect.Width/2, rect.Height/2), 2,SpriteEffects.None, 0);
        }

        public Vector2 GetPos()
        {
            return pos; // new Vector2(pos.X - rect.Width/2, pos.Y - rect.Height/2);
        }

        public Rectangle GetHitBox()
        {
            return hitBox;
        }
    }
}
