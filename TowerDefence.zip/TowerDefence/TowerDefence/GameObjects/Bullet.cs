﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerDefence.GameObjects
{
    class Bullet : GameObject
    {
        float speed;
        Vector2 velocity;
        Vector2 dir;

        Enemy enemy;

        Rectangle hitBox;

        public int Damage { get; }

        public bool ToRemoveBullet { get; private set; }

        public Bullet(Texture2D tex, Vector2 pos, Rectangle rect, Enemy enemy, float speed) : base(tex, pos, rect)
        {
            this.speed = speed;
            this.enemy = enemy;

            hitBox.Width = rect.Width;
            hitBox.Height = rect.Height;

            Damage = 2;

        }

        public override void Update()
        {
            hitBox.X = (int)pos.X;
            hitBox.Y = (int)pos.Y;

            if (enemy.HealthPoints > 0)
            {

                dir = (enemy.GetPos() - pos);

                dir.Normalize();

                velocity = dir * speed;

                pos += velocity;

                ToRemoveBullet = false;
            }
            else
            {
                ToRemoveBullet = true;
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, pos, rect, Color.White);
        }

        public Vector2 GetPos()
        {
            return pos;
        }

        public Rectangle GetHitBox()
        {
            return hitBox;
        }
    }
}
