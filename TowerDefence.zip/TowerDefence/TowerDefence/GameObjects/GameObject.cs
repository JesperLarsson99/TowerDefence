﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerDefence.GameObjects
{
    public abstract class GameObject
    {
        protected Texture2D tex;
        protected Vector2 pos;
        protected Rectangle rect;

        public GameObject(Texture2D tex, Vector2 pos, Rectangle rect)
        {
            this.tex = tex;
            this.pos = pos;
            this.rect = rect;
        }

        public abstract void Update();

        public abstract void Draw(SpriteBatch spriteBatch);
    }
}
