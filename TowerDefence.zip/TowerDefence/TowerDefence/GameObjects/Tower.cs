﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerDefence.GameObjects
{
    class Tower : GameObject
    {
        Rectangle hitBox;
        Rectangle bulletRect;

        Bullet b;

        Texture2D bulletTex;

        List<Bullet> bullets = new List<Bullet>();
        List<Enemy> enemies = new List<Enemy>();

        int shoot;

        public Tower(Texture2D tex, Vector2 pos, Rectangle rect, Texture2D bulletTex, Rectangle bulletRect, List<Enemy> enemies) : base (tex, pos, rect)
        {
            hitBox = new Rectangle(0, 0, 68, 68);
            this.bulletRect = bulletRect;
            this.bulletTex = bulletTex;
            this.enemies = enemies;

            shoot = 0;
        }

        public override void Update()
        {
            shoot++;

            Bullet toRemoveBullet = null;
            Enemy toRemoveEnemy = null;

            hitBox.X = (int)pos.X;
            hitBox.Y = (int)pos.Y;

            foreach (var e in enemies)
            {
                if (shoot >= 100)
                {
                    b = new Bullet(bulletTex, pos, bulletRect, e, 2);
                    bullets.Add(b);
                    shoot = 0;
                }
            }

            foreach (var b in bullets)
            {
                foreach (var e in enemies)
                {
                    b.Update();

                    if (b.ToRemoveBullet)
                    {
                        toRemoveBullet = b;
                    }

                    if (b.GetHitBox().Intersects(e.GetHitBox()))
                    {
                        e.HealthPoints -= b.Damage;
                        toRemoveBullet = b;
                    }

                    if (e.HealthPoints <= 0)
                    {
                        toRemoveEnemy = e;
                    }
                }
            }
            if (enemies.Count == 0)
            {
                bullets.Clear();
            }

            if (toRemoveBullet != null)
            {
                bullets.Remove(toRemoveBullet);
            }
            if (toRemoveEnemy != null)
            {
                enemies.Remove(toRemoveEnemy);
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, pos, rect, Color.White);

            foreach (var b in bullets)
            {
                b.Draw(spriteBatch);
            }
        }

        public Rectangle getRect()
        {
            return rect;
        }

        public Texture2D getTex()
        {
            return tex;
        }

        public Rectangle getHitBox()
        {
            return hitBox;
        }
    }
}
