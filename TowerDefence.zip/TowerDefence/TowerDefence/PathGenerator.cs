﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Spline;

namespace TowerDefence
{
    class PathGenerator
    {
        public static SimplePath path;
        Texture2D road;

        float texPos;

        List<Vector2> vectorList = new List<Vector2>();

        Vector2 pos;

        public PathGenerator(GraphicsDevice graphicsDevice, ContentManager Content)
        {
            path = new SimplePath(graphicsDevice);
            road = Content.Load<Texture2D>(@"road");

            path.Clean();


            path.AddPoint(new Vector2(0, 100));
            path.AddPoint(new Vector2(100, 100));
            path.AddPoint(new Vector2(100, 250));
            path.AddPoint(new Vector2(300, 150));
            path.AddPoint(new Vector2(250, 300));
            path.AddPoint(new Vector2(500, 200));
            path.AddPoint(new Vector2(400, 350));
            path.AddPoint(new Vector2(650, 200));
            path.AddPoint(new Vector2(600, 400));
            path.AddPoint(new Vector2(800, 300));

            texPos = path.beginT;
        }

        public void Update()
        {
            pos = path.GetPos(texPos);

            if (texPos < path.endT)
            {
                Vector2 tempPos = pos;
                vectorList.Add(tempPos);
                texPos += 20;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (var v in vectorList)
            {
                spriteBatch.Draw(road, new Rectangle((int)v.X, (int)v.Y, 40, 40), new Rectangle(0, 0, road.Width, road.Height), Color.White, 1f, new Vector2(road.Width / 2, road.Height / 2), SpriteEffects.None, 0);
            }
        }
    }
}
