﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TowerDefence.GameObjects;

namespace TowerDefence
{
    class EnemyManager
    {
        Texture2D tex;
        Rectangle rect;

        List<Enemy> enemies = new List<Enemy>();

        Enemy enemy;

        int spawnTimer;

        public EnemyManager(ContentManager Content)
        {
            tex = Content.Load<Texture2D>(@"ghost");
            rect = new Rectangle(0, 16, 17, 16);

            spawnTimer = 0;

            enemy = new Enemy(tex, Vector2.Zero, rect);
            enemies.Add(enemy);
        }

        public void Update()
        {
            Enemy toRemove = null;

            spawnTimer++;

            if (spawnTimer >= 200)
            {
                enemy = new Enemy(tex, Vector2.Zero, rect);
                enemies.Add(enemy);

                spawnTimer = 0;
            }

            foreach (var e in enemies)
            {
                e.Update();

                if (e.ReachEnd)
                {
                    toRemove = e;
                }
            }

            if (toRemove != null)
            {
                enemies.Remove(toRemove);
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (var e in enemies)
            {
                e.Draw(spriteBatch);
            }
        }

        public List<Enemy> getEnemies()
        {
            return enemies;
        }
    }
}
