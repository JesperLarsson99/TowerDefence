﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TowerDefence.GameObjects;

namespace TowerDefence
{
    class TowerManager
    {
        Texture2D tex;
        Texture2D bulletTex;

        Rectangle rect;
        Rectangle bulletRect;

        List<Tower> towers = new List<Tower>();

        Tower tower;

        RenderTarget2D renderTarget;

        EnemyManager enemyManager;

        public TowerManager(ContentManager Content, RenderTarget2D renderTarget, EnemyManager enemyManager)
        {
            tex = Content.Load<Texture2D>(@"tower");
            bulletTex = Content.Load<Texture2D>(@"shot");

            rect = new Rectangle(68, 0, 68, 68);
            bulletRect = new Rectangle(32, 256, 32, 32);

            this.renderTarget = renderTarget;
            this.enemyManager = enemyManager;
        }

        public void Update()
        {

            if (KeyMouseReader.LeftClick())
            {
                tower = new Tower(tex, new Vector2(KeyMouseReader.mouseState.X - rect.Width / 2, KeyMouseReader.mouseState.Y - rect.Height / 2), rect, bulletTex, bulletRect, enemyManager.getEnemies());
                if (CanPlace(tower))
                {
                    towers.Add(tower);
                }
            }

            foreach (var t in towers)
            {
                t.Update();
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (var t in towers)
            {
                t.Draw(spriteBatch);
            }
        }

        public bool CanPlace(Tower t)
        {
            Color[] pixels = new Color[t.getRect().Width * t.getRect().Height];
            Color[] pixels2 = new Color[t.getRect().Width * t.getRect().Height];

            t.getTex().GetData(0, t.getRect(), pixels2, 0, pixels.Length);

            renderTarget.GetData(0, new Rectangle(KeyMouseReader.mouseState.X - rect.Width / 2, KeyMouseReader.mouseState.Y - rect.Height / 2, 68, 68), pixels, 0, pixels.Length);

            for (int i = 0; i < pixels.Length; ++i)
            {
                if (pixels[i].A > 0.0f && pixels2[i].A > 0.0f)
                    return false;
            }

            return true;
        }
    }
}
